""""
In this file all mathematical constants are defined

So far, onle the Global epsilon "G_EPSILON" is defined.
"""

G_EPSILON = 1E-11
