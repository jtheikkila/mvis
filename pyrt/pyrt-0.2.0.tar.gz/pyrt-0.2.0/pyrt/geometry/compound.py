"""
This is the compound shape description

(renderable object)
"""
from ..geometry import Shape, Parallelogram, Cylinder, Disk
import uuid
from ..material import Material, PhongMaterial
from ..math import Vec3

class Compound(object):
    """This is the base class for all compound geometries"""

    def __init__(self, name: str) -> None:
        self.name = name
        self.material = None
        self.components = []
        self.id = str(uuid.uuid4())
        
    def parts(self) -> list:
        return self.components
    
    def add(self, item) -> None:
        if 'compound' in str(item.__class__):
            self.components += item.components
        else:
            self.components.append(item)
    

class Parallelepiped(Compound):
    """The Parallelepiped class for raytracing"""

    def __init__(self, center: Vec3, xdir: Vec3, ydir: Vec3, zdir: Vec3, material: Material = PhongMaterial()) -> None:
        Compound.__init__(self, "Parallelepiped")

        self.material = material
        
        self.add(Parallelogram(center, xdir, ydir, material))
        self.add(Parallelogram(center, xdir, zdir, material))
        self.add(Parallelogram(center, ydir, zdir, material))
        center = center + xdir + ydir + zdir
        xdir = -1. * xdir; ydir = -1. * ydir; zdir = -1. * zdir
        self.add(Parallelogram(center, xdir, ydir, material))
        self.add(Parallelogram(center, xdir, zdir, material))
        self.add(Parallelogram(center, ydir, zdir, material))
        

class ClosedCylinder(Compound):
    """The ClosedCylinder class for raytracing"""

    def __init__(self, center: Vec3, axis: Vec3, radius: float, material: Material = PhongMaterial()) -> None:
        Compound.__init__(self, "ClosedCylinder")
  
        normal = axis.copy().normalize()
        self.add(Cylinder(center, axis, radius, material))
        self.add(Disk(center+axis, normal, radius, material))
        self.add(Disk(center, -1.0*normal, radius, material))

        
        
        