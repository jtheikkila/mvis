"""
This is the geometry module, containing maily shapes.

Also the vertex specification is found here.
"""

from .vertex import Vertex
from .shape import Shape
from .triangle import Triangle
from .sphere import Sphere
from .bbox import BBox
from .trianglemesh import TriangleMesh
from .cylinder import Cylinder
from .disk import Disk
from .parallelogram import Parallelogram
from .planartexture import PlanarTexture
from .compound import Compound
from .compound import Parallelepiped
from .compound import ClosedCylinder
