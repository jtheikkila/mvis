"""
This is the geometric object Parallelogram

(renderable object)
"""

from ..geometry import Shape
from ..math import Ray, HitRecord, Vec3, dot3, G_EPSILON, cross3
from ..material import Material, PhongMaterial
from .bbox import BBox
from math import sqrt, pi


class Parallelogram(Shape):

    """The Parallelogram class for raytracing"""

    def __init__(self, center: Vec3, xvec: Vec3, yvec: Vec3, material: Material = PhongMaterial()) -> None:
        Shape.__init__(self, "Parallelogram")
        
        self.center = center
        self.normal = cross3(xvec, yvec).normalize()
        self.material = material
        self.xvec = xvec
        self.yvec = yvec


    def hit(self, ray: Ray, hitrecord: HitRecord) -> bool:
        """
        Hit ray with a plane.

        :param ray: the ray to check hit
        :param hitrecord: the hitrecord which is only valid if there is a hit
        :return: True if there is a hit
        """
        t0 = hitrecord.t
        x1 = self.xvec[0]; x2 = self.xvec[1]; x3 = self.xvec[2]         
        y1 = self.yvec[0]; y2 = self.yvec[1]; y3 = self.yvec[2]
        
        a11 = x1 ** 2 + x2 ** 2 + x3 ** 2
        a12 = a21 = x1 * y1 + x2 * y2 + x3 * y3
        a22 = y1 ** 2 + y2 ** 2 + y3 ** 2
        
        det = a11 * a22 - a12 * a21
        den = dot3(ray.direction, self.normal)
        
        if det == 0 or den == 0:
            return False       
        
        t = ((dot3(self.center, self.normal) - dot3(ray.start, self.normal))
             / den)
        
        if t0 is not None and t0 < t:
            return False

        x = ray.start + t * ray.direction
              
        # pseudoinverse
        p = x - self.center
        q1 = x1 * p[0] + x2 * p[1] + x3 * p[2]
        q2 = y1 * p[0] + y2 * p[1] + y3 * p[2]
        a = (a22 * q1 - a12 * q2) / det
        b = (a11 * q2 - a21 * q1) / det
        
        
        if a > 0.0 and a < 1.0 and b > 0.0 and b < 1.0 and t > 0.0:
            hitrecord.t = t
            hitrecord.point = x
            hitrecord.normal_g = self.normal
            hitrecord.normal = hitrecord.normal_g            
            hitrecord.color = Vec3(1., 1., 1.)
            hitrecord.material = self.material
            self.a = a
            self.b = b
            return True
        return False            


    def hitShadow(self, ray: Ray) -> bool:
        """
        :param ray:
        :param tmin:
        :param tmax:
        :return:
        """
        
        x1 = self.xvec[0]; x2 = self.xvec[1]; x3 = self.xvec[2]         
        y1 = self.yvec[0]; y2 = self.yvec[1]; y3 = self.yvec[2]
        
        a11 = x1 ** 2 + x2 ** 2 + x3 ** 2
        a12 = a21 = x1 * y1 + x2 * y2 + x3 * y3
        a22 = y1 ** 2 + y2 ** 2 + y3 ** 2

        det = a11 * a22 - a12 * a21 
        den = dot3(ray.direction, self.normal)
        
        if det == 0 or den == 0:
            return False

        t = ((dot3(self.center, self.normal) - dot3(ray.start, self.normal))
             / den)
        x = ray.start + t * ray.direction        
        
        p = x - self.center
        q1 = x1 * p[0] + x2 * p[1] + x3 * p[2]
        q2 = y1 * p[0] + y2 * p[1] + y3 * p[2]
        a = (a22 * q1 - a12 * q2) / det
        b = (a11 * q2 - a21 * q1) / det
        
        if a > 0 and a < 1 and b > 0 and b < 1 and t > 0:
            return True
        return False
