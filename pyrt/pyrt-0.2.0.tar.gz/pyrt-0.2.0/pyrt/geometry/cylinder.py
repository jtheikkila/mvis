"""
This is the geometric object cylinder

(renderable object)
"""

from ..geometry import Shape
from ..math import Ray, HitRecord, Vec3, dot3, G_EPSILON
from ..material import Material, PhongMaterial
from math import sqrt


class Cylinder(Shape):

    """The Cylinder class for raytracing"""

    def __init__(self, center: Vec3, axis: Vec3, radius: float, material: Material = PhongMaterial()) -> None:
        Shape.__init__(self, "Cylinder")

        self.center = center
        self.axis = axis
        self.radius = radius
        self.material = material
        self.aa = dot3(axis, axis)
        self.cc = dot3(center, center)
        self.ac = dot3(axis, center)
        self.rr = radius * radius


    def hit(self, ray: Ray, hitrecord: HitRecord) -> bool:
        """
        Hit ray with cylinder.

        :param ray: the ray to check hit
        :param hitrecord: the hitrecord which is only valid if there is a hit
        :return: True if there is a hit
        """
        t0 = hitrecord.t
        
        d = ray.direction.normalize()
        
        p1 = -1.0 * self.aa
        p2 = dot3(self.axis, d)
        p3 = dot3(self.axis, ray.start) - self.ac
        
        q5 = 2.0 * dot3(d, ray.start - self.center)
        q6 = self.cc + dot3(ray.start, ray.start - 2.0 * self.center) - self.rr
        
        ta = p1 * (p1 + p2 ** 2) 
        tb = p1 * (p1 * q5 + 2 * p2 * p3)
        tc = p1 * (p1 * q6 + p3 ** 2)
        
        D = tb * tb + (-4.0) * ta * tc
        if D < G_EPSILON:
            return False

        D = sqrt(D)
        t1 = -0.5*(tb + D) / ta
        t2 = -0.5*(tb - D) / ta
        b1 = -(p2 * t1 + p3) / p1
        b2 = -(p2 * t2 + p3) / p1
        
        tf1 = b1 >= 0.0 and b1 <= 1.0
        tf2 = b2 >= 0.0 and b2 <= 1.0
        
        if tf1 and tf2:
            t = min(t1, t2)
            b = -(p2 * t + p3) / p1
        elif tf1:
            t = t1; b = b1
        elif tf2:
            t = t2; b = b2
        else:
            return False

        if t0 is not None and t0 < t:
            return False

        if t>0:
            hitrecord.t = t
            hitrecord.point = ray.start + t * ray.direction
            axispoint = self.center + b * self.axis
            hitrecord.normal_g = (hitrecord.point - axispoint) / self.radius
            hitrecord.normal = hitrecord.normal_g
            hitrecord.color = Vec3(1., 1., 1.)  # cylinders don't have interpolated colors, set to white
            hitrecord.material = self.material
            return True
        return False



    def hitShadow(self, ray: Ray) -> bool:
        """
        :param ray:
        :param tmin:
        :param tmax:
        :return:
        """
        
        d = ray.direction.normalize()
        
        p1 = -1.0 * self.aa
        p2 = dot3(self.axis, d)
        p3 = dot3(self.axis, ray.start) - self.ac
        
        q5 = 2.0 * dot3(d, ray.start - self.center)
        q6 = self.cc + dot3(ray.start, ray.start - 2.0 * self.center) - self.rr
        
        ta = p1 * (p1 + p2 ** 2) 
        tb = p1 * (p1 * q5 + 2 * p2 * p3)
        tc = p1 * (p1 * q6 + p3 ** 2)
        
        D = tb * tb + (-4.0) * ta * tc
        if D < G_EPSILON:
            return False

        D = sqrt(D)
        t1 = -0.5*(tb + D) / ta
        t2 = -0.5*(tb - D) / ta
        b1 = -(p2 * t1 + p3) / p1
        b2 = -(p2 * t2 + p3) / p1

        tf1 = b1 >= 0.0 and b1 <= 1.0
        tf2 = b2 >= 0.0 and b2 <= 1.0
        
        if tf1 and tf2:
            t = min(t1, t2)
            b = -(p2 * t + p3) / p1
        elif tf1:
            t = t1; b = b1
        elif tf2:
            t = t2; b = b2
        else:
            return False

        if t > 0:
            return True
        return False


