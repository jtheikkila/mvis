"""
This is the geometric object disk

(renderable object)
"""

from ..geometry import Shape
from ..math import Ray, HitRecord, Vec3, dot3, G_EPSILON
from ..material import Material, PhongMaterial
from .bbox import BBox
from math import sqrt, pi


class Disk(Shape):

    """The Disk class for raytracing"""

    def __init__(self, center: Vec3, normal: Vec3, radius: float, material: Material = PhongMaterial()) -> None:
        Shape.__init__(self, "Disk")

        self.center = center
        self.normal = normal
        self.radius = radius
        self.material = material


    def hit(self, ray: Ray, hitrecord: HitRecord) -> bool:
        """
        Hit ray with disk.

        :param ray: the ray to check hit
        :param hitrecord: the hitrecord which is only valid if there is a hit
        :return: True if there is a hit
        """
        t0 = hitrecord.t
        
        t = ((dot3(self.center, self.normal) - dot3(ray.start, self.normal))
             / dot3(ray.direction, self.normal))
        x = ray.start + t * ray.direction
        d = (x-self.center).length()

        if t0 is not None and t0 < t:
            return False
        
        if d < self.radius:
            hitrecord.t = t
            hitrecord.point = x
            hitrecord.normal_g = self.normal
            hitrecord.normal = hitrecord.normal_g
            hitrecord.color = Vec3(1., 1., 1.)  # disks don't have interpolated colors, set to white
            hitrecord.material = self.material
            return True
        return False            


    def hitShadow(self, ray: Ray) -> bool:
        """
        :param ray:
        :param tmin:
        :param tmax:
        :return:
        """
        t = ((dot3(self.center, self.normal) - dot3(ray.start, self.normal))
             / dot3(ray.direction, self.normal))
        x = ray.start + t * ray.direction
        d = (x-self.center).length()
        
        if d < self.radius and t > 0:
            return True
        return False


    def getBBox(self):
        """
        Retrieve axis aligned bounding box of the sphere


        :return: bounding box
        """
        bbmin = Vec3(self.center - Vec3(self.radius, self.radius, self.radius))
        bbmax = Vec3(self.center + Vec3(self.radius, self.radius, self.radius))
        return BBox(bbmin, bbmax)


    def getCentroid(self) -> Vec3:
        """
        Retrieve center of sphere
        :return:
        """
        return self.center


    def getSurfaceArea(self):
        """
        Retrieve surface area

        :return: surface area
        """
        return 4. * pi * self.radius**2