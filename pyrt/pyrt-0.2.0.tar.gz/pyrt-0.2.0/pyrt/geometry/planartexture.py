"""
This is the geometric object PlanarTexture

(renderable object)
"""

from ..geometry import Parallelogram
from ..math import Ray, HitRecord, Vec3, dot3, G_EPSILON, cross3
from ..material import Material, PhongMaterial


class PlanarTexture(Parallelogram):

    """The PlanarTexture class for raytracing"""

    def __init__(self, center: Vec3, xvec: Vec3, yvec: Vec3, texture, material: Material = PhongMaterial()) -> None:
        Parallelogram.__init__(self, center, xvec, yvec, material)
        self.name = "PlanarTexture"
        self.texture = texture / 255.0
        self.M, self.N, _ = texture.shape


    def hit(self, ray: Ray, hitrecord: HitRecord) -> bool:
        """
        Hit ray with a plane.

        :param ray: the ray to check hit
        :param hitrecord: the hitrecord which is only valid if there is a hit
        :return: True if there is a hit
        """
        if Parallelogram.hit(self, ray, hitrecord):
            xi = self.a * (self.N - 1)
            yi = self.b * (self.M - 1)
            xi0, yi0 = int(xi), int(yi)
            xi1, yi1 = xi0 + 1, yi0 + 1
            p00 = [xi0, yi0, self.texture[yi0, xi0, 0]]
            p01 = [xi0, yi1, self.texture[yi0, xi1, 0]]
            p10 = [xi1, yi0, self.texture[yi1, xi0, 0]]
            p11 = [xi1, yi1, self.texture[yi1, xi1, 0]]
            ri = self._bilinear_interpolation(xi, yi, [p00, p01, p10, p11])
            p00[2] = self.texture[yi0, xi0, 1]
            p01[2] = self.texture[yi0, xi1, 1]
            p10[2] = self.texture[yi1, xi0, 1]
            p11[2] = self.texture[yi1, xi1, 1]
            gi = self._bilinear_interpolation(xi, yi, [p00, p01, p10, p11])
            p00[2] = self.texture[yi0, xi0, 2]
            p01[2] = self.texture[yi0, xi1, 2]
            p10[2] = self.texture[yi1, xi0, 2]
            p11[2] = self.texture[yi1, xi1, 2]
            bi = self._bilinear_interpolation(xi, yi, [p00, p01, p10, p11])            
            hitrecord.color = Vec3(ri, gi, bi)
            return True
        return False            


    def _bilinear_interpolation(self, x, y, points):
        '''Interpolate (x,y) from values associated with four points.

        The four points are a list of four triplets:  (x, y, value).
        The four points can be in any order.  They should form a rectangle.

            >>> bilinear_interpolation(12, 5.5,
            ...                        [(10, 4, 100),
            ...                         (20, 4, 200),
            ...                         (10, 6, 150),
            ...                         (20, 6, 300)])
            165.0
            
        Source code from: https://stackoverflow.com/questions/8661537/
        how-to-perform-bilinear-interpolation-in-python

        '''
        # See formula at:  http://en.wikipedia.org/wiki/Bilinear_interpolation

        points = sorted(points)               # order points by x, then by y
        (x1, y1, q11), (_x1, y2, q12), (x2, _y1, q21), (_x2, _y2, q22) = points

        if x1 != _x1 or x2 != _x2 or y1 != _y1 or y2 != _y2:
            raise ValueError('points do not form a rectangle')
        if not x1 <= x <= x2 or not y1 <= y <= y2:
            raise ValueError('(x, y) not within the rectangle')

        return (q11 * (x2 - x) * (y2 - y) +
                q21 * (x - x1) * (y2 - y) +
                q12 * (x2 - x) * (y - y1) +
                q22 * (x - x1) * (y - y1)
               ) / ((x2 - x1) * (y2 - y1) + 0.0)

