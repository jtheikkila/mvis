"""
This is the light module, containing different light types

If you want to add your light, do it here...
"""


from .light import Light
from .pointlight import PointLight
from .ambient import AmbientLight
