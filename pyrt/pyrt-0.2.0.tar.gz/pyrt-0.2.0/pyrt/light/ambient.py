"""
This is the definition for a point light

A point light emits light to all directions. It can be somewhat compared to a light bulb.

"""
from .light import Light
from ..math import Vec3


class AmbientLight(Light):

    """Class describing an ambient light source"""

    def __init__(self, color = Vec3(1.,1.,1.), brightness:float = 0.5) -> None:
        """
        Constructor

        Not yet complete - params will change in near future!
        :param position: position of the light
        """
        Light.__init__(self, "AmbientLight")
        self.position = None
        self.color = color * brightness



