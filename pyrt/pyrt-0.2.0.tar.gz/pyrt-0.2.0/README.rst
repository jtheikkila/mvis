A modified version of PyRT - The Python Raytracer by Martin Christen.

To install run:
python3 setup.py install

Version 0.2.0
